const fs = require('fs-extra');
const concat = require('concat');
(async function build() {
  const files = [
    './dist/online-banking/runtime-es2015.js',
    './dist/online-banking/polyfills-es2015.js',
    './dist/online-banking/main-es2015.js',
  ]
  await fs.ensureDir('elements')
  await concat(files, 'elements/boa-footer.js');
  await fs.copyFile('./dist/online-banking/styles.css', 'elements/styles.css')
  await fs.copy('./dist/online-banking/assets/', 'elements/assets/' )
})()